import mysql.connector
import bcrypt
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.image import Image
from kivy.uix.button import Button
from kivy.graphics import Color, RoundedRectangle
from kivy.uix.label import Label
from kivy.graphics import Color, Rectangle
from kivy.core.text import LabelBase
from kivy.uix.image import Image


def connect_to_database():
    try:
        return mysql.connector.connect(
            host='127.0.0.1', user='root', passwd='', database='omni')
    except mysql.connector.Error as err:
        print("Erreur de connexion à la base de données:", err)
        raise

def hash_mot_de_passe(mot_de_passe):
    return bcrypt.hashpw(mot_de_passe.encode(), bcrypt.gensalt())

def verifier_mot_de_passe(mot_de_passe, mot_de_passe_hache):
    return bcrypt.checkpw(mot_de_passe.encode(), mot_de_passe_hache)

class InscriptionScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.create_ui()

    def create_ui(self):
        layout = FloatLayout()
        bg_image = Image(source='img.jpg', allow_stretch=True, keep_ratio=False, size_hint=(1, 1))
        layout.add_widget(bg_image)
        logo = Image(source='teccart.png', size_hint=(0.5, 0.5), pos_hint={'top': 1, 'center_x': 0.5})
        layout.add_widget(logo)


        box = BoxLayout(orientation='vertical', padding=10, spacing=10, size_hint=(0.3, 0.3), pos_hint={'center_x': 0.5, 'center_y': 0.5})
        titre = CustomLabel(
           text="INSCRIPTION",
           font_size='24sp',
           color=(0, 0, 0, 1), 
           font_name='Roboto',  
           size_hint=(1, 0.1),
           halign="center"  
)
        box.add_widget(titre)
        retour_btn = Button(
            text="Retour",
            size_hint=(0.1, 0.1),
            pos_hint={'x': 0, 'y': 0}, 
            background_color=(1, 0, 0, 1),  
            color=(0, 0, 0, 1)  
        )
        retour_btn.bind(on_press=self.retour)
        layout.add_widget(retour_btn)

        self.nom_input = TextInput(hint_text='Nom', size_hint_y=None, height=50)
        self.prenom_input = TextInput(hint_text='Prénom', size_hint_y=None, height=50)
        self.code_permanent_input = TextInput(hint_text='Code permanent', size_hint_y=None, height=50)
        self.mot_de_passe_input = TextInput(hint_text='Mot de passe', password=True, size_hint_y=None, height=50,)

        inscription_button = Button(text='S\'inscrire', size_hint_y=None, height=50,)
        inscription_button.bind(on_press=self.inscrire_etudiant)

        box.add_widget(self.nom_input)
        box.add_widget(self.prenom_input)
        box.add_widget(self.code_permanent_input)
        box.add_widget(self.mot_de_passe_input)
        box.add_widget(inscription_button)

        layout.add_widget(box)
        self.add_widget(layout)


    def retour(self, instance):
        self.manager.current = self.manager.previous()


    def inscrire_etudiant(self, instance):
        nom = self.nom_input.text
        prenom = self.prenom_input.text
        code_permanent = self.code_permanent_input.text
        mot_de_passe_hache = hash_mot_de_passe(self.mot_de_passe_input.text)

        if isinstance(mot_de_passe_hache, bytes):
            mot_de_passe_hache = mot_de_passe_hache.decode()

        conn = connect_to_database()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO etudiant (nom, prenom, code_permanent, mot_de_passe) VALUES (%s, %s, %s, %s)
            ''', (nom, prenom, code_permanent, mot_de_passe_hache))
            conn.commit()
            self.manager.current = 'connexion'
        except mysql.connector.Error as err:
            print("Erreur lors de l'insertion de l'étudiant:", err)
        finally:
            cursor.close()
            conn.close()


class ConnexionScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.create_ui()

    def create_ui(self):
        layout = FloatLayout()
        bg_image = Image(source='calender.jpg', allow_stretch=True, keep_ratio=False, size_hint=(1, 1))
        layout.add_widget(bg_image)
        logo = Image(source='teccart.png', size_hint=(0.5, 0.5), pos_hint={'top': 1, 'center_x': 0.5})
        layout.add_widget(logo)


        box = BoxLayout(orientation='vertical', padding=10, spacing=10, size_hint=(0.3, 0.3), pos_hint={'center_x': 0.5, 'center_y': 0.5})
     
        retour_btn = Button(
            text="Retour",
            size_hint=(0.1, 0.1),
            pos_hint={'x': 0, 'y': 0},  
            background_color=(1, 0, 0, 1),  
            color=(0, 0, 0, 1)  
        )
        retour_btn.bind(on_press=self.retour)
        layout.add_widget(retour_btn)

        


        self.code_permanent_input = TextInput(hint_text='Code permanent', size_hint_y=None, height=60)
        self.mot_de_passe_input = TextInput(hint_text='Mot de passe', password=True, size_hint_y=None, height=60)
        self.message_erreur = Label(text='', color=(1, 0, 0, 1))

        connexion_button = Button(text='Connexion', size_hint_y=None, height=50)
        connexion_button.bind(on_press=self.verifier_connexion)

        box.add_widget(self.code_permanent_input)
        box.add_widget(self.mot_de_passe_input)
        box.add_widget(connexion_button)
        box.add_widget(self.message_erreur)

        layout.add_widget(box)
        self.add_widget(layout)
        
    def retour(self, instance):
        self.manager.current = self.manager.previous()

    def verifier_connexion(self, instance):
        code_permanent = self.code_permanent_input.text
        mot_de_passe = self.mot_de_passe_input.text

        conn = connect_to_database()
        cursor = conn.cursor(buffered=True)
        try:
            cursor.execute('''
                SELECT mot_de_passe FROM etudiant WHERE code_permanent = %s
            ''', (code_permanent,))
            resultat = cursor.fetchone()

            if resultat and verifier_mot_de_passe(mot_de_passe, resultat[0].encode('utf-8')):
                self.manager.current = 'gestion_cours'
            else:
                self.message_erreur.text = "Connexion échouée : Code permanent ou mot de passe incorrect"
        except mysql.connector.Error as err:
            print("Erreur lors de la vérification de la connexion:", err)
            self.message_erreur.text = "Erreur de connexion"
        finally:
            cursor.close()
            conn.close()

class GestionCoursScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.create_ui()

    def create_ui(self):
        layout = FloatLayout()
        bg_image = Image(source='image.jpg', allow_stretch=True, keep_ratio=False, size_hint=(1, 1))
        layout.add_widget(bg_image)
      

        box = BoxLayout(orientation='vertical', padding=10, spacing=10, size_hint=(0.3, 0.3), pos_hint={'center_x': 0.5, 'center_y': 0.5})

       
        self.titre_input = TextInput(hint_text='Titre du cours', size_hint_y=None, height=50)
        self.programme_input = TextInput(hint_text='Programme', size_hint_y=None, height=50)
        self.nombre_heures_input = TextInput(hint_text='Nombre d\'heures', size_hint_y=None, height=50)
        self.prof_input = TextInput(hint_text='Professeur', size_hint_y=None, height=50)
        ajouter_cours_button = Button(text='Ajouter Cours', size_hint_y=None, height=50)
        ajouter_cours_button.bind(on_press=self.ajouter_cours)

        box.add_widget(self.titre_input)
        box.add_widget(self.programme_input)
        box.add_widget(self.nombre_heures_input)
        box.add_widget(self.prof_input)
        box.add_widget(ajouter_cours_button)

        afficher_cours_button = Button(text='Cours souhaites', size_hint_y=None, height=50)
        afficher_cours_button.bind(on_press=self.afficher_cours)
        box.add_widget(afficher_cours_button)

        layout.add_widget(box)
        self.add_widget(layout)



    def ajouter_cours(self, instance):
        titre = self.titre_input.text
        programme = self.programme_input.text
        nombre_heures = self.nombre_heures_input.text
        prof = self.prof_input.text

        conn = connect_to_database()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO cours (titre, programme, nombre_heures, prof) VALUES (%s, %s, %s, %s)
            ''', (titre, programme, nombre_heures, prof))
            conn.commit()
        except mysql.connector.Error as err:
            print("Erreur lors de l'insertion du cours:", err)
        finally:
            cursor.close()
            conn.close()

        self.titre_input.text = ''
        self.programme_input.text = ''
        self.nombre_heures_input.text = ''
        self.prof_input.text = ''
        
    def afficher_cours(self, instance):
        if 'affichage_cours' in self.manager.screen_names:
            affichage_cours_screen = self.manager.get_screen('affichage_cours')
            affichage_cours_screen.afficher_cours()
            self.manager.current = 'affichage_cours'
        else:
           
            affichage_cours_screen = AffichageCoursScreen(name='affichage_cours')
            self.manager.add_widget(affichage_cours_screen)
            affichage_cours_screen.afficher_cours()
            self.manager.current = 'affichage_cours'


class AffichageCoursScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.create_ui()

    def create_ui(self):
        self.layout = BoxLayout(orientation='vertical', padding=10, spacing=10)
        self.add_widget(self.layout)  
        layout = FloatLayout()
        
        
        self.layout = BoxLayout(orientation='vertical', padding=10, spacing=10, size_hint=(1, 0.9), pos_hint={'center_x': 0.5, 'center_y': 0.5})
        layout.add_widget(self.layout)

        
        retour_btn = Button(
            text="Retour",
            size_hint=(0.1, 0.1),
            pos_hint={'x': 0, 'y': 0},
            background_color=(1, 0, 0, 1), 
            color=(0, 0, 0, 1) 
        )
        retour_btn.bind(on_press=self.retour)
        layout.add_widget(retour_btn)

        self.add_widget(layout)
    def retour(self, instance):
        self.manager.current = self.manager.previous()

    

    

        

    def afficher_cours(self):
        conn = connect_to_database()
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT id, titre, programme, nombre_heures, prof FROM cours")
            cours = cursor.fetchall()
            self.layout.clear_widgets()
            for cours_id, titre, programme, nombre_heures, prof in cours:
                cours_box = BoxLayout(orientation='horizontal', padding=5, size_hint_y=None, height=40)
                cours_label = Label(text=f"{titre} ({programme}) - {nombre_heures}h, Prof: {prof}", size_hint_x=0.8)
                cours_box.add_widget(cours_label)

                supprimer_btn = Button(text='Supprimer', size_hint_x=0.2)
                supprimer_btn.bind(on_press=lambda instance, x=cours_id: self.callback_supprimer_cours(x))
                cours_box.add_widget(supprimer_btn)

                self.layout.add_widget(cours_box)
        except mysql.connector.Error as err:
            print("Erreur lors de l'affichage des cours:", err)
        finally:
            cursor.close()
            conn.close()

    def supprimer_cours(self, cours_id):
        conn = connect_to_database()
        cursor = conn.cursor()
        try:
            cursor.execute("DELETE FROM cours WHERE id = %s", (cours_id,))
            conn.commit()
        except mysql.connector.Error as err:
            print("Erreur lors de la suppression du cours:", err)
        finally:
            cursor.close()
            conn.close()
        self.rafraichir_affichage_cours()

    def callback_supprimer_cours(self, cours_id):
        self.supprimer_cours(cours_id)

    def rafraichir_affichage_cours(self):
        self.afficher_cours()


class StyledButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.draw_button()

    def draw_button(self):
        with self.canvas.before:
            Color(1, 0, 0, 1) 
            self.rect = RoundedRectangle(size=self.size, pos=self.pos, radius=[10])

        
        self.bind(pos=self.update_rect, size=self.update_rect)

    def update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size
class CustomLabel(Label):
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.draw_label()

    def draw_label(self):
        with self.canvas.before:
            
            Color(0.9, 0.9, 0.9, 1)  
            self.rect = Rectangle(size=self.size, pos=self.pos)

        with self.canvas.after:
        
            Color(0, 0, 0, 0.5)  
            self.shadow = Rectangle(size=self.size, pos=(self.pos[0] + 1, self.pos[1] - 1))

        
        self.bind(pos=self.update_graphics, size=self.update_graphics)

    def update_graphics(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos
        self.shadow.size = self.size
        self.shadow.pos = (self.pos[0] + 1, self.pos[1] - 1)


class CoursApp(App):
    def build(self):
        sm = ScreenManager()
        sm.add_widget(InscriptionScreen(name='inscription'))
        sm.add_widget(ConnexionScreen(name='connexion'))
        sm.add_widget(GestionCoursScreen(name='gestion_cours'))
        sm.add_widget(AffichageCoursScreen(name='affichage_cours'))
        sm.current = 'inscription'
        return sm

if __name__ == '__main__':
    CoursApp().run()

